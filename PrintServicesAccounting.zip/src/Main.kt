fun main() {
    println("Hello")
}